sudo systemctl start mongod
sudo systemctl status mongod
