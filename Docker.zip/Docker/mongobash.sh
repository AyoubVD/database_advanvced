sudo apt-get install -y mongodb
sudo service mongodb stop
sudo service mongodb start
