sudo apt-get install -y redis-server
sudo service redis-server start
